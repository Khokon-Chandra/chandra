<?php
namespace core;

class Rule
{
    public function rules()
    {
        return [
            'required'
        ];
    }
}