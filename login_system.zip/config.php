<?php

define('APP_KEY', "KD83475JDSFLJ9859H6LJ09Q34JF156446T42");

define('BASE_URL', __DIR__);

define('APP_URL', 'https://demo.kpl-bd.com');


// database information


define('DB_HOST', 'kpl-bd.com');
define('DB_NAME', 'kplbd_demo');
define('USER_NAME', 'kplbd_app_admin');
define('PASSWORD', '5@[NtV6Nae+r');
