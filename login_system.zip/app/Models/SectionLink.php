<?php

namespace app\Models;

use core\Database\Model;

class SectionLink extends Model
{

    protected $table = 'section_links';

    
}
