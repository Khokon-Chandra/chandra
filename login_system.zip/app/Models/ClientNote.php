<?php

namespace app\Models;

use core\Database\Model;

class ClientNote extends Model
{

    protected $table = 'client_notes';

    
}
