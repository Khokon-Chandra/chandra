<?php

namespace app\Models;

use core\Database\Model;

class LinkSp extends Model
{

    protected $table = 'link_sp';
    
}
