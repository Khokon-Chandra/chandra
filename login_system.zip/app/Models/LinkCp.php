<?php

namespace app\Models;

use core\Database\Model;

class LinkCp extends Model
{

    protected $table = 'link_cp';

    
}
