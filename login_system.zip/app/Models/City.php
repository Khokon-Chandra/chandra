<?php

namespace app\Models;

use core\Database\Model;

class City extends Model
{

    protected $table = 'cities';

    
}
