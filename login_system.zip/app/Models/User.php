<?php

namespace app\Models;

use core\Database\Model;

class User extends Model
{
    
    protected $table = 'users';

   
}