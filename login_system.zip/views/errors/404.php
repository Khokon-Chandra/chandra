<x-layouts.guest>

<div class="text-center">
    <h1><?= $code ?></h1>
    <h2><?= $message ?></h2>
</div>
    
</x-layouts.guest>