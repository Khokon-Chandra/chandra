<div class="row">
    <div class="col-4">
    <div class="form-group">
        <label for="">Company Name</label>
        <input type="text" name="company" class="form-control form-control-sm">
    </div>
    <div class="form-group">
        <label for="">Company Name</label>
        <input type="text" name="company" class="form-control form-control-sm">
    </div>
    <div class="form-group">
        <label for="">Company Name</label>
        <input type="text" name="company" class="form-control form-control-sm">
    </div>
    </div>
</div>